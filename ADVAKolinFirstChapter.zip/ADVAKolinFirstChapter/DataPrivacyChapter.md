# Chapter 13: Data Privacy

```metadata
author: "By Kolin Stürt"
number: "13"
title: "Chapter 13: Data Privacy"
section: 4
```

With all the recent data breaches and new privacy laws, such as the [CCPA](https://oag.ca.gov/privacy/ccpa), [PIPEDA](https://www.priv.gc.ca/en/privacy-topics/privacy-laws-in-canada/the-personal-information-protection-and-electronic-documents-act-pipeda/) and [GDPR](https://en.wikipedia.org/wiki/General_Data_Protection_Regulation), your app’s credibility depends on how you manage your user’s data. While security is important to users and lawmakers alike, it remains an often neglected aspect of mobile app development. There are powerful Android APIs focusing on data privacy that are sometimes overlooked when beginning a project. You can put them to great use and think of security from the ground up.

To assist developers, Android 11 offers new [privacy advancements](https://developer.android.com/preview/privacy) and device enhancements, including scoped storage, hardened permissions, biometric authentication and hardware-backed key storage.

In this chapter, you’ll learn how to:

* Store a password securely.
* Protect saved data.
* Use encryption.

## Getting Started

This chapter starts off with simple approaches to protect your app. As the chapter goes on, the implementation gets more fine-tuned and advanced. You can stop at any time if you've got what you needed. If you need to implement a simple login for your app. Great. If you project requires customized protocols, carry on to the end of the chapter.

If you missed the previous chapters, the sample app includes a list of pets, their medical data, and a section that lets you report safety issues anonymously. Launch the starter app for this chapter. You’ll see the simple sign-up screen. Once you enter an email and select Sign Up, the list of pets will populate. Tap the **Report** tab to report a concern:

![bordered width=60%](/images/ReportSection.png)

## Implementing the Login

The app saves data about you such as home address for the pet, login passwords, medical history of your pet and any safety reports you've sent. If someone were to take your device or a backup, they’ll be able to see all that personal information. To ensure only you can access that app data, it's standard to require a password. Modern devices have some form of biometric readers. Face, retina and fingerprint scanners are all examples. You’ll implement a biometric prompt to log in to the app so that only you can access the app on your device. You'll also implement a password fallback to give the user a chance for an alternative. 

First check that the device can use biometrics. In **MainActivity.kt**, replace the contents of `loginPressed()` with the code block below:

```kotlin
val biometricManager = BiometricManager.from(this)
when (biometricManager.canAuthenticate()) {
  BiometricManager.BIOMETRIC_SUCCESS ->
    displayLogin(view, false)
  BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE ->
    displayLogin(view, true)
  BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE ->
    toast("Biometric features are currently unavailable.")
  BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ->
    toast("Please associate a biometric credential with your account.")
  else ->
    toast("An unknown error occurred. Please check your Biometric settings")
}
```

The app calls `displayLogin()` if the device can perform biometric authentication with `BIOMETRIC_SUCCESS`. Otherwise, the `fallback` flag is set to `true`, allowing for password or pin authentication.

Add the following variables to the class:

```kotlin
private lateinit var biometricPrompt: BiometricPrompt
private lateinit var promptInfo: BiometricPrompt.PromptInfo
```

where `BiometricPrompt` is a class from AndroidX. Next, replace the contents of `displayLogin()` with the following:

```kotlin
val executor = Executors.newSingleThreadExecutor()
biometricPrompt = BiometricPrompt(this, executor, // 1
    object : BiometricPrompt.AuthenticationCallback() {
      override fun onAuthenticationError(errorCode: Int,
                                         errString: CharSequence) {
        super.onAuthenticationError(errorCode, errString)
        runOnUiThread {
          toast("Authentication error: $errString")
        }
      }

      override fun onAuthenticationFailed() {
        super.onAuthenticationFailed()
        runOnUiThread {
          toast("Authentication failed")
        }
      }

      override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {// 2
        super.onAuthenticationSucceeded(result)

        runOnUiThread {
          toast("Authentication succeeded!")
          if (!isSignedUp) {
            generateSecretKey() // 3
          }
          performLoginOperation(view)
        }
      }
    })

if (fallback) {
  promptInfo = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Biometric login for my app")
      .setSubtitle("Log in using your biometric credential")
      // Cannot call setNegativeButtonText() and
      // setDeviceCredentialAllowed() at the same time.
      // .setNegativeButtonText("Use account password")
      .setDeviceCredentialAllowed(true) // 4
      .build()
} else {
  promptInfo = BiometricPrompt.PromptInfo.Builder()
      .setTitle("Biometric login for my app")
      .setSubtitle("Log in using your biometric credential")
      .setNegativeButtonText("Use account password")
      .build()
}
biometricPrompt.authenticate(promptInfo)
```

Here’s what’s happening:

1. You create an object, `BiometricPrompt`, for authentication.
2. You override `onAuthenticationSucceeded` to determine a successful authentication.
3. You create a secret key that’s tied to the authentication for first-time users.
4. You allow a fallback to password authentication by calling `.setDeviceCredentialAllowed(true)`.

Be sure you have a face, fingerprint or similar biometric scanner on your device to test the biometric part. Build and run. You should be able to log in with your credential:

![bordered width=40%](/images/BiometricPrompt.png)

On successful authentication, you’ll see the pet list:

![bordered width=40%](/images/AnimalsNearYou.png)

That was easy. You’ve secured access to the app with biometric security!

There's a lot to digest here. Deciding to use biometrics depends on your threat model - where you use a risk-based approach to make decisions. People can use biometrics maliciously. An example of that is when someone steals and holds your phone up to your face while you’re unconscious, or when law enforcement holds your device to your finger after they handcuff you. In cases like this a passcode is always better. On the other hand, biometrics are better if your users are in the spotlight with people streaming to social media. There isn't the chance a live streamer will capture their password.

Secondly, even though access is limited now, your data such as reports and your password are not encrypted. Encryption uses a key to scramble the data. But if it's all done in the app then how is that any better? You'll address all that next, but first a little theory...

### Exploring Hardware Security Modules

A **Trusted Execution Environment** (TEE) is software separate from the OS. It safely sandboxes security operations, and while inside the main processor, it’s cordoned off from the main OS. Security keys that are isolated this way are _hardware-backed_. You can find out if a key is hardware-backed using `KeyInfo.isInsideSecureHardware()`.

An example of a TEE is the ARM processor that has the TrustZone secure enclave, available in modern Samsung phones.

A **Secure Element** (SE) takes this a step further by putting the environment on a segregated chip. It has its own CPU and storage, as well as encryption and random-number generator methods. Security chips that exist outside of the main processor make it harder to attack. Google’s devices contain the Titan M security chip, which is a SE.

In both cases, security operations happen at the hardware level in a separate environment that is less susceptible to software exploits.

Android 9 and above provides the [StrongBox Keymaster API](https://developer.android.com/training/articles/keystore#HardwareSecurityModule) for these features. To ensure the key exists inside a segregated secure element, you can call `KeyGenParameterSpec.Builder.setIsStrongBoxBacked(true)`.

Time to put this information to use!

### Hardening Data in The KeyStore

You’ll use `MasterKeys` to generate a key in the KeyStore. This will encrypt your reports that you wish to send.

As you learned above, the benefit of storing a key in the KeyStore is that it allows the OS to operate on it without exposing the secret contents of that key: Key data does not enter the app space.

For devices that don’t have a security chip, permissions for private keys only allow for your app to access the keys — and only after user authorization. This means that a lock screen must be set up on the device before you can make use of the credential storage. This makes it more difficult to extract keys from a device, called extraction prevention.

The security library contains two new classes, `EncryptedFile` and `EncryptedSharedPreferences`. In **Encryption.kt**, there are a few empty boilerplate methods set up for you. Replace the  `encryptFile()` method with this:

```kotlin
fun encryptFile(context: Context, file: File) : EncryptedFile {
  val keyGenParameterSpec = MasterKeys.AES256_GCM_SPEC
  val masterKeyAlias = MasterKeys.getOrCreate(keyGenParameterSpec) // 1
  return EncryptedFile.Builder(
      file,
      context,
      masterKeyAlias,
      EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB // 2
  ).build()
}
```

This is what you did:

1. Either create a new master key or retrieve one already created.
2. Encrypt the file using the popular secure AES encryption algorithm.

In **ReportDetailFragment.kt**, find `sendReportPressed()`. Replace the two lines right after `//TODO: Replace below for encrypting the file` with the code block below:

```kotlin
val file = File(theContext.filesDir?.absolutePath, "$reportID.txt") // 1
val encryptedFile = encryptFile(theContext, file) // 2
encryptedFile.openFileOutput().bufferedWriter().use {
    it.write(reportString) // 3
}
```

What you changed:

1. You create a file with a name `"$reportID.txt"`.
2. You create an `EncryptedFile` instance using the file object created in the last step.
3. You use the `EncryptedFile` instance to write to file all the report data.


You’ve hardened the data stored on the device by using a key that is secured in the keystore. This is a great step. But to make the data more secure, you can have the key tied to your biometric or password credentials. That way, if someone were to access that cordoned off key, it would be useless without your credentials.

## Securing Data With Biometrics

You can auto-generate a key in KeyStore that is also protected by your biometric credential. If the device becomes compromised, the key will be encrypted. This time you'll get a bit more advanced. Instead of using a high-level `EncryptedFile`, you'll use an encryption class so that you can customize what you want to encrypt later. This is powerful because you can encrypt items in a database, or some information to send over a network, for example.

In **Encryption.kt**, add the following to `generateSecretKey()`:

```kotlin
val keyGenParameterSpec = KeyGenParameterSpec.Builder(
    KEYSTORE_ALIAS,
    KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
    .setBlockModes(KeyProperties.BLOCK_MODE_GCM) // 1
    .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
    .setUserAuthenticationRequired(true) // 2
    .setUserAuthenticationValidityDurationSeconds(120) // 3
    .build()
val keyGenerator = KeyGenerator.getInstance(
    KeyProperties.KEY_ALGORITHM_AES, PROVIDER) // 4
keyGenerator.init(keyGenParameterSpec)
keyGenerator.generateKey()
```

Here’s the changes that you made:

1. You chose GCM, a popular and safe-block mode that the encryption uses. (More on this later).
2. You require a lock screen to be set up and the key locked until the user authenticates by passing in `.setUserAuthenticationRequired(true)`. Enabling the requirement for authentication also revokes the key when the user removes or changes the lock screen.
3. You made the key available for 120 seconds from password authentication with `.setUserAuthenticationValidityDurationSeconds(120)`. Passing in `-1` requires fingerprint authentication every time you want to access the key.
4. You create a `KeyGenerator` with the above settings and set it the `AndroidKeyStore` `PROVDER`.

There are a few more options worth mentioning here:

* `setRandomizedEncryptionRequired(true)` enables the requirement that there’s enough randomization. If you encrypt the same data a second time, that encrypted output will still be different. This prevents an attacker from gaining clues about the ciphertext based on feeding in the same data.
* Another option is `.setUserAuthenticationValidWhileOnBody(boolean remainsValid)`. It locks the key once the device has detected it is no longer on the person.

Because you use the same key and cipher in different parts of the app, add the following helper functions to **Encryption.kt**, under the companion object code block:

```kotlin
private fun getSecretKey(): SecretKey {
  val keyStore = KeyStore.getInstance(PROVIDER)

  // Before the keystore can be accessed, it must be loaded.
  keyStore.load(null)
  return keyStore.getKey(KEYSTORE_ALIAS, null) as SecretKey
}

@TargetApi(23)
private fun getCipher(): Cipher {
  return Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES + "/"
      + KeyProperties.BLOCK_MODE_GCM + "/"
      + KeyProperties.ENCRYPTION_PADDING_NONE)
}
```

The first function returns the secret key from the keystore. The second one returns a pre-configured `Cipher`. That's what you'll use next to do the actual encryption.

### Encrypting Data

You’ve stored the key in the KeyStore protected by your credentials. Right now the user's generated password is stored in the clear. You'll update the login method to encrypt it using the `Cipher` object, given the `SecretKey`. In the `Encryption` class, replace the contents of `createLoginPassword()` with the following:

```kotlin
val cipher = getCipher()
val secretKey = getSecretKey()
val random = SecureRandom()
val passwordBytes = ByteArray(256)
random.nextBytes(passwordBytes) // 1
cipher.init(Cipher.ENCRYPT_MODE, secretKey)
val ivParameters = cipher.parameters.getParameterSpec(GCMParameterSpec::class.java)
val iv = ivParameters.iv
PreferencesHelper.saveIV(context, iv) // 2
return cipher.doFinal(passwordBytes) // 3
```

Here’s what’s happening in that code:

1. You create a random password using `SecureRandom`.
2. You gather a randomized initialization vector (IV) required to decrypt the data and save it into the shared preferences.
3. Your return a `ByteArray` containing the encrypted data.

### Decrypting Data

You’ve encrypted the password, so now you need to decrypt it when the user authenticates. Replace the contents of `decryptPassword()` with the code below:

```kotlin
val cipher = getCipher()
val secretKey = getSecretKey()
val iv = PreferencesHelper.iv(context) // 1
val ivParameters = GCMParameterSpec(128, iv)
cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameters) // 2
return cipher.doFinal(password) // 3
```

Here’s what’s happening:

1. You retrieve the IV required to decrypt the data.
2. You initialize Cipher using `DECRYPT_MODE`.
3. You return a decrypted `ByteArray`.

Back in **MainActivity.kt**, find `performLoginOperation()`. Replace the line that calls `createDataSource` where it says `//TODO: Replace with encrypted data source below`:

```kotlin
val encryptedInfo = createLoginPassword(this)
createDataSource(it, encryptedInfo)
```

On sign up, you create a password for the account. Right after the `//TODO: Replace below with the implementation that decrypts the password`, replace `success = true` with the following:

```kotlin
val password = decryptPassword(this,
    Base64.decode(firstUser.password, Base64.NO_WRAP))
if (password.isNotEmpty()) {
  //Send password to authenticate with server etc
  success = true
}
```

On log in, you retrieve the password to decrypt the data. The app shouldn’t work without the key. Build and run. Then try to log in. You should encounter the following exception:

![bordered width=100%](/images/NullException.png)

That’s because no key was created on the previous sign up.

Delete the app to remove the old saved state. Then rebuild and run the app. You should now be able to log in. :]

![bordered width=26%](/images/AnimalsNearYou.png)

You’ve created an encrypted password that will only be available once you’ve authenticated with your credentials. Your data is safely protected. Since you've started using a `Cipher` object, that now opens the door to powerful customization. You can stop here, but if you want to learn about advanced encrpytion or your company requires you to use certain protocols, feel free to carry on.

## Customizing Your Encryption

Now it's time to explore a more advanced side of encryption. In this part you’ll focus on the recommended standard for encryption, Advanced Encryption Standard (AES). AES uses a substitution–permutation network to encrypt your data with a key. Using this approach, it replaces bytes from one table with the bytes from another, and as such creates permutations of data. Just like before, AES requires an encryption key. You'll customize how a key is created.

### Creating a Key

As mentioned above, AES uses a key for encryption. That same key is also used to decrypt the data. This is called symmetric encryption. The key can be different specific lengths, but 256 bits is standard. Directly using the user’s password for encryption is dangerous. It likely won’t be random or large enough. A function called _Password-Based Key Derivation Function_ (PBKDF2) comes to the rescue. It takes a password and, by hashing it with random data many times over, creates a key. That random data is called a _salt_. PBKDF2 creates a strong and unique key, even if someone else uses the same password or a very simple password.

Because each key is unique, if an attacker steals and publishes the key online, it doesn’t expose all the users that used the same password. Start by generating the salt. Open up the **Encryption.kt** file, and add the following code to the `encrypt` method, where it reads `//TODO: Add custom encrypt code here`:

```kotlin
val random = SecureRandom()
val salt = ByteArray(256)
random.nextBytes(salt)
```

Here, you use the `SecureRandom` class, which makes sure that the output is difficult to predict. That’s called a _cryptographically strong random number generator_ and you should always use a secure class like this, instead of `java.util.Random` for example. Now, you’ll generate a key with the user’s password and the salt. Add the following right under the code you just added:

```kotlin
val pbKeySpec = PBEKeySpec(password, salt, 1324, 256) // 1
val secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1") // 2
val keyBytes = secretKeyFactory.generateSecret(pbKeySpec).encoded // 3
val keySpec = SecretKeySpec(keyBytes, "AES") // 4
```

Here’s what is going on inside that code. You:

1. Put the salt and password into `PBEKeySpec`, a password-based encryption object. The constructor takes an iteration count (`1324`). The higher the number, the longer it would take to operate on a set of keys during a brute force attack.
2. Passed `PBEKeySpec` into the `SecretKeyFactory`.
3. Generated the key as a `ByteArray`.
4. Wrapped the raw `ByteArray` into a `SecretKeySpec` object.

Now you've got a secure key. The next part of customization involves the mode of operation.

### Choosing an Encryption Mode

The mode is simply how the data is processed. For example, there's Electronic Code Book (ECB). It's very simple in that it splits up the data and repeats the encryption process for every chunk with the same key. Because the same key is used for each block this mode is highly insecure. Don't use this mode. 

Counter Mode (CTR) uses a counter so that each block encrypts differently. CTR is efficient and safe to use. There's a few other modes that are useful: GCM offers authentication in addition to encryption, whereas XTS is optimized for full disk encryption. You'll use CBC (Cipher Block Chaining) where each block of plaintext is XORed with the previous block.

You're almost ready to encrypt but there's one more thing you need to consider when it comes to modes.

### Adding an Initialization Vector

As mentioned above, you'll be using the standard mode, **cipher block chaining** (CBC), that encrypts your data one chunk at a time. Because each block of data in the pipeline is [XOR](https://whatis.techtarget.com/definition/logic-gate-AND-OR-XOR-NOT-NAND-NOR-and-XNOR)’d with the previous block that it encrypted - that dependency on previous blocks makes the encryption strong, but can you see a problem? What about the first block?

If you encrypt a message that starts off the same as another message, the first encrypted block would be the same! That provides a clue for an attacker and you don't want that. In fact, this idea is known as _Perfect Secrecy_: the ciphertext conveys zero information about the plaintext. To remedy the first block problem, you’ll use an _initialization vector_ (IV).

An IV is a fancy term for a block of random data that gets XOR’d with that first block. Remember that each block relies on all blocks processed up until that point. This means that identical sets of data encrypted with the same key will not produce identical outputs.

Create an IV now by adding the following code right after the code you just added:

```kotlin
val ivRandom = SecureRandom() //not caching previous seeded instance of SecureRandom
val iv = ByteArray(16)
ivRandom.nextBytes(iv) // 1
val ivSpec = IvParameterSpec(iv) // 2
```

Here, you:

1. Created 16 bytes of random data.
2. Packaged it into an `IvParameterSpec` object.

### Finalizing the Encryption

Now that you have all the necessary pieces, you can finally get to the encryption! Add the following code to perform the customized encryption:

```kotlin
val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding") // 1
cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivSpec)
val encrypted = cipher.doFinal(dataToEncrypt) // 2
```

Here:

1. You passed in the specification string `“AES/CBC/PKCS7Padding”`. It chooses AES with cipher block chaining mode. _PKCS7Padding_ is a well-known standard for padding. Since you’re working with blocks, not all data will fit perfectly into the block size, so you need to pad the remaining space. By the way, blocks are 128 bits long and AES adds padding before encryption.
2. `doFinal` does the actual encryption.

Next, add the following:

```kotlin
map["salt"] = salt
map["iv"] = iv
map["encrypted"] = encrypted
```

You packaged the encrypted data into a `HashMap`. You also added the salt and initialization vector to the map. That’s because all those pieces are necessary to decrypt the data. It's not the only way to go about this. It's common to concatenate the IV to the beginning of the ciphertext and then strip it off and use it for the decryption. For learning, a map is a clearer than getting distracted with sub-arrays and off-by-one counts. :] 

If you followed the steps correctly, you shouldn’t have any errors and the `encrypt` function is ready to secure some data! It’s okay to store salts and IVs, but reusing or sequentially incrementing them weakens the security. You should never store the key! Right about now, you built the means of encrypting this data, but you still need to decrypt it. You'll see how to do that now.

### Decrypting with Salts and IVs

You’ve got some encrypted data. In order to decrypt it, you’ll have to change the mode of `Cipher` in the init method from `ENCRYPT_MODE` to `DECRYPT_MODE`. Add the following to the `decrypt` method in the **Encryption.kt** file, right where the line reads `//TODO: Add custom decrypt code here`:

```kotlin
// 1
val salt = map["salt"]
val iv = map["iv"]
val encrypted = map["encrypted"]

// 2
//regenerate key from password
val pbKeySpec = PBEKeySpec(password, salt, 1324, 256)
val secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
val keyBytes = secretKeyFactory.generateSecret(pbKeySpec).encoded
val keySpec = SecretKeySpec(keyBytes, "AES")

// 3
//Decrypt
val cipher = Cipher.getInstance("AES/CBC/PKCS7Padding")
val ivSpec = IvParameterSpec(iv)
cipher.init(Cipher.DECRYPT_MODE, keySpec, ivSpec)
decrypted = cipher.doFinal(encrypted)
```

In this code, you did the following:

1. Used the `HashMap` that contains the encrypted data, salt and IV necessary for decryption.
2. Regenerated the key given that information plus the user’s password.
3. Decrypted the data and returned it as a `ByteArray`.

Notice how you used the same configuration for the decryption, but have traced your steps back. This is because you’re using a symmetric encryption algorithm. You can now encrypt data as well as decrypt it!

Oh and, did I mention never to store the key? :]

### Updating the Saving Method

Now that the encryption process is complete, you’ll need to test it. The app is already writing data to storage.

In the **ReportDetailFragment.kt** file, uncomment the line below `//TODO: Test your custom encryption here`. Then add the following to the `testCustomEncryption` method:

```kotlin
val password = REPORT_SESSION_KEY.toCharArray()
val bytes = reportString.toByteArray(Charsets.UTF_8)
val map = Encryption.encrypt(bytes, password) // 1
val reportID = UUID.randomUUID().toString()
val outFile = File(activity?.filesDir?.absolutePath, "$reportID.txt")
ObjectOutputStream(FileOutputStream(outFile)).use { // 2
  it.writeObject(map)
}

//TEST decrypt
val decryptedBytes = Encryption.decrypt(map, password) // 3
decryptedBytes?.let {
  val decryptedString = String(it, Charsets.UTF_8)
  Log.e("Encrpytion Test", "The decrypted string is: $decryptedString") // 4
}
```

In the updated code:
1. You fed the data into the encryption method.
2. Saved the encrypted data.
3. You called the decrypt method using the encrypted data, IV and salt.
4. Tested that it worked.


If you build and run the application now, you should see the correct string:

![bordered width=100%](/images/StringConsoleTest.png "Encryption Test")

## Key Points

Congratulations! You've gone from adding simple data protection to some advanced customization. It’s great to know how to properly implement security. Armed with this knowledge, you’ll be able to confirm if third-party security libraries are up to the best practices.

* Simple login with passcode or biometrics
* You can tie that to protect your data and keys in the keystore
* Encrypted file are high level encryption helpers that you can use with those keys
* You can customize the encrypting using the Cipher object

You've secured your data at rest. With the knowledge you've just learned, in the next chapter you will secure the data in transit.
